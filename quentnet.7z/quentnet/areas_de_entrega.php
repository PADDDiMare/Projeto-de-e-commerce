<?php require_once("inc/header.php"); ?>
	
    <main role="main">

      <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="first-slide" src="images/areas-de-entrega.jpg" alt="First slide">
            <div class="container">
            </div>
          </div>
        </div>
      </div>


      <!-- Mensagens de marketing e outras featurezinhas
      ================================================== -->
      <!-- Envolve o resto da página em outro container, para centralizar todo o conteúdo. -->

      <div class="container marketing">
			
			<h2>Áreas de Entrega</h2><br>
			<p class="text-justify">Informe seu CEP no campo abaixo e descubra se seu endereço encontra-se em nossa área de entrega.</p>
		<form class="form-inline">
			<div class="form-group mb-2">
				<label for="staticEmail2" class="sr-only">Email</label>
			</div>
			<div class="form-group mx-sm-3 mb-2">
				<label for="inputPassword2" class="sr-only">CEP</label>
				<input type="password" class="form-control" id="inputPassword2" placeholder="CEP">
			</div>
			<button type="submit" class="btn btn-danger mb-2">Continuar</button>
		</form>

        <!-- COMEÇAM AS MENCIONADAS FEATUREZINHAS xD -->

        <hr class="featurette-divider">

        <!-- /FIM DAS FEATUREZINHAS *-* -->

      </div><!-- /.container -->


<?php require_once("inc/footer.php"); ?>
