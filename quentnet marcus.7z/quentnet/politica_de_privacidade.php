<?php require_once("inc/header.php"); ?>

      <div class="container marketing">
			<br>
			<h2>Segurança e Privacidade</h2>
			<p class="text-justify">A sua segurança é prioridade para QuentNet. “Não divulgamos dados pessoais a outras instituições em hipótese alguma, a não ser no cumprimento de ordens emitidas por autoridades públicas, policiais e judiciárias.”.</p>
			<p class="text-justify">Todas as suas informações que passam pelo nosso sistema - desde a sua senha pessoal até os dados de seu cartão de crédito - são codificadas. As operações são criptografadas e, por isso, não podem ser lidas nem alteradas por terceiros. Também só utilizamos as informações fornecidas por você pra prestação dos nossos serviços quando necessário.</p>
			<p class="text-justify">Nosso sistema de proteção durante as movimentações pela internet é o mesmo usado pelas principais instituições financeiras. Já reparou no cadeado fechado que está no cantinho inferior da tela? Ele é a garantia de que utilizamos uma empresa especializada em te fornecer um ambiente seguro.</p>
			<p class="text-justify">Ao comprar pela primeira vez no site da QuentNet é preciso que você preencha o seu cadastro. Nas vezes seguintes, só será necessário informar seu login (e-mail) e senha, o que vai facilitar a finalização das suas próximas compras. Apenas os seus dados cadastrais ficarão armazenados em nosso sistema como: nome, sexo, telefone, e-mail, cep e data de nascimento.</p>
			<p class="text-justify">O número de seu cartão de crédito e quaisquer outras informações sobre pagamento não permanecerão armazenados, isso só ocorre se você optar por comprar com 1 click, onde as informações cadastrais de cartões de crédito escolhidos por você ficarão armazenadas em seu perfil, em sigilo, exibindo somente os últimos quatro números do cartão. Lembrando que somente você poderá ter acesso às informações ou alterá-las mediante senha (é só conferir o item ‘segurança na compra’).</p>
			<p class="text-justify">Você terá acesso online ao seu cadastro, podendo retificar quaisquer informações que estejam erradas em qualquer hora, viu? A QuentNet não será responsável por verificar ou atualizar o cadastro, então o preenchimento correto fica por sua conta!</p>
			<p class="text-justify">Se você esquecer a sua senha, não tem problema! É só entrar na tela de login e clicar em esqueci a senha ou entrar em contato direto com a QuentNet! Lembre que você é o único responsável por guardar de modo seguro a sua senha!</p>
			<p class="text-justify">Terceiros poderão coletar dados de navegação, você pode desautorizar essa coleta em http://optout.t.tailtarget.com.</p>
			<p class="text-justify">Por fim, se você quiser saber mais sobre nossa política de privacidade, entre em contato conosco! Caso queira remover o seu cadastro por completo do nosso site, é só nos avisar!</p>
			<br><h2>Segurança e Privacidade</h2>
			<p class="text-justify">A criptografia é uma tecnologia avançada, que permite transformar em código a linguagem comum em que todo dado pessoal é transmitido, durante um processo de compra pela internet.</p>
			<p class="text-justify">Desta forma, ao comprar no nosso site, toda e qualquer informação que você fornecer a QuentNet (sejam os dados pessoais ou as informações de pagamento) será automaticamente codificada antes de ser transmitida e arquivada em ambiente interno próprio - que é de acesso exclusivo da nossa equipe.</p>
			<br><h2>Compras com cartões de crédito</h2>
			<p class="text-justify">A QuentNet não retém números de cartões de crédito, isso só ocorre se você optar por comprar com 1 click, onde as informações cadastrais de cartões de crédito escolhidos por você ficarão em sigilo, apenas armazenadas em seu perfil que exibirá somente os últimos quatro números do cartão. Somente você poderá ter acesso às informações ou alterá-las mediante senha.</p>
			<p class="text-justify">É importante lembrar que, durante esse processo de transmissão de dados, você estará em um ambiente de comércio eletrônico seguro garantido. Como você pode ver no ícone de cadeado que aparece logo ali embaixo, no rodapé do seu navegador!</p>

        <!-- COMEÇAM AS MENCIONADAS FEATUREZINHAS xD -->

        <hr class="featurette-divider">

        <!-- /FIM DAS FEATUREZINHAS *-* -->

      

<?php require_once("inc/footer.php"); ?>
