<?php require_once("inc/header.php"); ?>
	
    <main role="main">

      <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="first-slide" src="images/areas-de-entrega.jpg" alt="First slide">
            <div class="container">
            </div>
          </div>
        </div>
      </div>


      <!-- Mensagens de marketing e outras featurezinhas
      ================================================== -->
      <!-- Envolve o resto da página em outro container, para centralizar todo o conteúdo. -->

      <div class="container marketing">
			
			
		<h2 class="mt-4">Áreas de Entrega</h2><br>

			<div class="row mb-3">
				<div class="col-4 themed-grid-col">Abolição</div>
				<div class="col-4 themed-grid-col">Alto da Boa Vista</div>
				<div class="col-4 themed-grid-col">Andaraí</div>
			</div>

			<div class="row mb-3">
				<div class="col-sm-4 themed-grid-col">Bancários</div>
				<div class="col-sm-4 themed-grid-col">Barra da Tijuca</div>
				<div class="col-sm-4 themed-grid-col">Botafogo</div>
			</div>

			<div class="row mb-3">
				<div class="col-md-4 themed-grid-col">Catete</div>
				<div class="col-md-4 themed-grid-col">Centro</div>
				<div class="col-md-4 themed-grid-col">Copacabana</div>
			</div>

			<div class="row mb-3">
				<div class="col-xl-4 themed-grid-col">Engenho de Dentro</div>
				<div class="col-xl-4 themed-grid-col">Engenho Novo</div>
				<div class="col-xl-4 themed-grid-col">Estácio</div>
			</div>
  
			<div class="row mb-3">
				<div class="col-xl-4 themed-grid-col">Flamengo</div>
				<div class="col-xl-4 themed-grid-col">Freguesia - Ilha Governador</div>
				<div class="col-xl-4 themed-grid-col">Freguesia - Jacarepaguá</div>
			</div>
  
			<div class="row mb-3">
				<div class="col-xl-4 themed-grid-col">Galeão</div>
				<div class="col-xl-4 themed-grid-col">Glória</div>
				<div class="col-xl-4 themed-grid-col">Grajaú</div>
			</div>
			
			<div class="row mb-3">
				<div class="col-xl-4 themed-grid-col">Higienópolis</div>
				<div class="col-xl-4 themed-grid-col">Honório Gurgel</div>
				<div class="col-xl-4 themed-grid-col">Humaitá</div>
			</div>
			
			<div class="row mb-3">
				<div class="col-xl-4 themed-grid-col">Ipanema</div>
				<div class="col-xl-4 themed-grid-col">Irajá</div>
				<div class="col-xl-4 themed-grid-col">Itanhangá</div>
			</div>

        <!-- COMEÇAM AS MENCIONADAS FEATUREZINHAS xD -->

        <hr class="featurette-divider">

        <!-- /FIM DAS FEATUREZINHAS *-* -->

      </div><!-- /.container -->


<?php require_once("inc/footer.php"); ?>
