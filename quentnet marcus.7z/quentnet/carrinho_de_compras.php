<?php require_once("inc/header.php"); ?>
	  
	  
	  <div class="container marketing">
			<br>
			<h2>Carrinho de Compras</h2><br>
				
				<table class="table table-bordered">
			  <thead>
				<tr>
				  <th scope="col" width="20%">Imagem</th>
				  <th scope="col"width="30%">Produto</th>
				  <th scope="col" width="30%">Quantidade</th>
				  <th scope="col" width="30%">Valor</th>
				</tr>
			  </thead>
			  <tbody>
				<tr>
				  <th scope="row"><img src="images/bife.png" style="padding:1px;  display: block; margin-left: auto; margin-right: auto"></th>
				  <td>Frango Xadrez</td>
				  <td><input name="" value="1" id="" class="form-control num" size="3" type="number" min="1" style="padding:6px; max-width:48px"></td>
				  <td>R$</td>
				</tr>
				<tr>
				  <th scope="row" colspan="2"><a href="" class="btn btn-danger my-2">Limpar Carrinho</a></th>
				  <td>Valor total</td>
				  <td>R$</td>
				</tr>
				</table>	
				
			<div class="row">
			  <div class="col-sm-6">
				<div class="card">
				  <div class="card-body">
					<h5 class="card-title">Forma de Pagamentos</h5>
					<p class="card-text"><select id="inputEstado" class="form-control">
					<option selected="">Dinheiro</option>
					<option>Cartão de Crédito</option>
					<option>Cartão de Débito</option>
					<option>Ticket Alimentação</option>
				</select></p>
				<p><img src="images/icones-cartoes.png">
				  </div>
				</div>
			  </div>
			  <div class="col-sm-6">
				<div class="card">
				  <div class="card-body">
					<h5 class="card-title">Observações</h5>
					<p class="card-text"><textarea class="form-control" id="exampleFormControlTextarea1" rows="7"></textarea></p>
				  </div>
				</div>
			  </div>
			</div>
			<br><br>
			<p>
				<a href="cardapio.php" class="btn btn-danger my-2">Continuar comprando</a>
			<a href="#" class="btn btn-danger my-2">Finalizar compra</a>
			</p>
		
        <hr class="featurette-divider">

<?php require_once("inc/footer.php"); ?>
