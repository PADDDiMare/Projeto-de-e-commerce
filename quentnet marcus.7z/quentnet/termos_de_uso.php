<?php require_once("inc/header.php"); ?>

      <div class="container marketing">
			<br>
			<h2>Termos de uso</h2>
			<p class="text-justify">Esse site foi produzido com muito cuidado para te oferecer serviços exclusivos! Abaixo seguem algumas regras básicas de uso.</p>
			<br><h2>Prazos</h2>
			<p class="text-justify">A QuentNet fará de tudo pra cumprir os prazos previstos neste regulamento. Porém, podem surgir pequenos imprevistos externos. Nesses casos, avisaremos aos clientes sobre eventuais atrasos.</p>
			<br><h2>Conteúdo Geral</h2>
			<p class="text-justify">Mesmo com o cuidado constante em oferecer o melhor serviço a todos, pode acontecer de algumas das informações contidas no nosso site conterem erros tipográficos, incorreções ou omissões relacionadas à descrição dos produtos, preços e disponibilidade. Assim que tais erros, incorreções ou omissões forem descobertas pela QuentNet ou avisados a ela, o site QuentNet se reserva ao direito de corrigi-los, modificando e atualizando as informações a qualquer hora, sem comunicação prévia. Claro, temos todo o cuidado pra evitar que isso ocorra!</p>
			<br><h2>Informações de Produtos</h2>
			<p class="text-justify">Nem todos os produtos apresentados em nossas redes sociais e em nossas lojas estão disponíveis pra compra no site QuentNet. Alguns itens divulgados em nossas redes sociais e em nosso site são meramente ilustrativos e não estão disponíveis pra venda.</p>
			<p class="text-justify">As informações sobre preços e disponibilidade de produtos estão sujeitas a alterações. Os preços no site podem ser diferentes dos praticados em nossas lojas próprias, devido a promoções e outras vantagens oferecidas pela QuentNet.</p>
			<p class="text-justify">As informações sobre a disponibilidade de produtos nos estoques do site QuentNet são constantemente atualizadas, porém, em determinados casos, em virtude de problemas técnicos, pode acontecer de não possuirmos em nossos estoques um determinado produto adquirido por você. Nesse caso, no menor prazo possível, avisaremos sobre o ocorrido e você poderá utilizar o crédito em outro produto ou solicitar a devolução integral dos valores quitados.</p>

        <!-- COMEÇAM AS MENCIONADAS FEATUREZINHAS xD -->

        <hr class="featurette-divider">

        <!-- /FIM DAS FEATUREZINHAS *-* -->

      

<?php require_once("inc/footer.php"); ?>
