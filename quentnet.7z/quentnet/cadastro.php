
<?php require_once("inc/header.php"); ?>

      <div class="container marketing">
			
			<br><h2>Cadastro</h2><br>
			<p class="text-justify">Por favor, preencha todo o formulário abaixo.</p>
			<form>
				<div class="form-row">
				<div class="form-group col-md-7">
					<label for="inputNome4"></label>
					<input type="text" class="form-control" id="inputNome4" placeholder="Nome Completo">
				</div>
				</div>
				<div class="form-row">
				<div class="form-group col-md-7">
					<label for="inputEmail"></label>
					<input type="text" class="form-control" id="inputEmail" placeholder="E-mail">
				</div>
				</div>
				<div class="form-check form-check-inline">
					<input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="opcao1">
					<label class="form-check-label" for="inlineRadio1">Masculino</label>
				</div>
				<div class="form-check form-check-inline">
					<input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="opcao2">
					<label class="form-check-label" for="inlineRadio2">Feminino</label>
				</div>
				<div class="form-row">
				<div class="form-group col-md-1">
					<label for="inputDDD"></label>
					<input type="text" class="form-control" id="inputDDD" placeholder="DDD">
				</div>
				<div class="form-group col-md-4">
					<label for="inputTel"></label>
					<input type="text" class="form-control" id="inputTel" placeholder="Telefone">
				</div>
				</div>
				<div class="form-row">
				<div class="form-group col-md-1">
					<label for="inputDDD"></label>
					<input type="text" class="form-control" id="inputDDD" placeholder="DDD">
				</div>
				<div class="form-group col-md-4">
					<label for="inputTel"></label>
					<input type="text" class="form-control" id="inputTel" placeholder="Celular">
				</div>
				</div>
				<div class="form-row">
				<div class="form-group col-md-4">
					<label for="inputTel"></label>
					<input type="text" class="form-control" id="inputTel" placeholder="CEP">
				</div>
				<div class="col-sm-2">
				<a href="http://www.buscacep.correios.com.br/sistemas/buscacep/" target="_blank"><img src="img/correios.png" style="margin-top:10px"></a>                          
				</div>
				</div>
				<div class="form-row">
				<div class="form-group col-md-7">
					<label for="inputNome4"></label>
					<input type="text" class="form-control" id="inputNome4" placeholder="Endereço">
				</div>
				</div>
				<div class="form-row">
				<div class="form-group col-md-7">
					<label for="inputEmail"></label>
					<input type="text" class="form-control" id="inputEmail" placeholder="Número">
				</div>
				</div>
				<div class="form-row">
				<div class="form-group col-md-7">
					<label for="inputEmail"></label>
					<input type="text" class="form-control" id="inputEmail" placeholder="Complemento">
				</div>
				</div>
				<div class="form-row">
				<div class="form-group col-md-7">
					<label for="inputEmail"></label>
					<input type="text" class="form-control" id="inputEmail" placeholder="Senha">
				</div>
				</div>
				<div class="form-row">
				<div class="form-group col-md-7">
					<label for="inputEmail"></label>
					<input type="text" class="form-control" id="inputEmail" placeholder="Confirmar senha"><br>
				</div>
				</div>
				
				
				<button type="submit" class="btn btn-danger">Continuar</button>
			</form>

        <!-- COMEÇAM AS MENCIONADAS FEATUREZINHAS xD -->

        <hr class="featurette-divider">

        <!-- /FIM DAS FEATUREZINHAS *-* -->

      <?php require_once("inc/footer.php"); ?>

