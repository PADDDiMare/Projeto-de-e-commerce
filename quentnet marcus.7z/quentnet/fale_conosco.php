<?php require_once("inc/header.php"); ?>

      <div class="container marketing">
			<br>
			<h2>Fale Conosco</h2><br>
			<p class="text-justify">Aqui é o seu espaço caso haja alguma dúvida, sugestão ou reclamações. Sua opinião é muito importante.</p>
			<form>
				<div class="form-row">
				<div class="form-group col-md-7">
					<label for="inputNome4"></label>
					<input type="text" class="form-control" id="inputNome4" placeholder="Nome Completo">
				</div>
				</div>
				<div class="form-row">
				<div class="form-group col-md-7">
					<label for="inputEmail"></label>
					<input type="text" class="form-control" id="inputEmail" placeholder="E-mail">
				</div>
				</div>
				<div class="form-row">
				<div class="form-group col-md-1">
					<label for="inputDDD"></label>
					<input type="text" class="form-control" id="inputDDD" placeholder="DDD">
				</div>
				<div class="form-group col-md-4">
					<label for="inputTel"></label>
					<input type="text" class="form-control" id="inputTel" placeholder="Telefone">
				</div>
				</div>
				<div class="form-row">
				<div class="form-group col-md-4">
						<label for="inputSituacao"></label>
				<select id="inputEstado" class="form-control">
					<option selected>Situação</option>
					<option>Crítica</option>
					<option>Sugestão</option>
					<option>Elogios</option>
					<option>Outros</option>
				</select>
				</div>
				</div><!-- /.container -->
				<div class="form-row">
				  <div class="form-group col-md-7">
					<label for="exampleFormControlTextarea1"></label>
						<textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
					</div>
				</div><br>
				<button type="submit" class="btn btn-danger">Enviar</button>
			</form>

        <!-- COMEÇAM AS MENCIONADAS FEATUREZINHAS xD -->

        <hr class="featurette-divider">

        <!-- /FIM DAS FEATUREZINHAS *-* -->

      

<?php require_once("inc/footer.php"); ?>
