<?php require_once("inc/header.php"); ?>

      <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="first-slide" src="images/oquentnet.jpg" alt="First slide">
            <div class="container">
            </div>
          </div>
        </div>
      </div>


      <!-- Mensagens de marketing e outras featurezinhas
      ================================================== -->
      <!-- Envolve o resto da página em outro container, para centralizar todo o conteúdo. -->

      <div class="container marketing">
			
			<h2>O QuentNet</h2><br>
			<p class="text-justify">A história do QuentNet começou em abril de 2006, quando o brasileiro Roberto Oliveira fundou a pequena loja de comida à kilo QuentNet, na Rua do Ouvidor, no Centro do Rio de Janeiro. O nome da casa teve como base as entregas de quentinhas e tecnologia.</p>
			<p class="text-justify">O restaurante foi se expandindo e diversificando sua cozinha, introduzindo novos conceitos na gastronomia carioca, como o famoso couvert e o medalhão. Com público extremamente fiel, o restaurante do Centro é o começo da "cultura" digital de entregas delivery como tradição carioca. Em 2009, a QuentNet chegou à Barra - bairro ainda pouco explorado na época - e, desde então, não parou de crescer.<p>
			<p class="text-justify">Atualmente são mais de 60 operações entre restaurantes e unidades de delivery e lanchonetes. Por trás de toda essa entrega ao cliente, está uma fábrica de 5 mil m², onde são produzidas receitas exclusivas de forma artesanal.</p>
			<p class="text-justify">Venha conhecer nossos serviço. Estaremos esperando por você de braços abertos! Se preferir, ligue e faça um pedido para o nosso serviço de entregas em domicílio 3460-0801.</p>



        <!-- COMEÇAM AS MENCIONADAS FEATUREZINHAS xD -->

        <hr class="featurette-divider">

        <!-- /FIM DAS FEATUREZINHAS *-* -->

      </div><!-- /.container -->


<?php require_once("inc/footer.php"); ?>