<?php require_once("inc/header.php"); ?>

      <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
          <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="first-slide" src="images/saladas.jpg" alt="First slide">
            <div class="container">
              <div class="carousel-caption">
                <h1>Segunda Vegana</h1>
                <p>Saladas frescas com ingredientes orgânicos. <br>Desfrute de uma alimentação mais saudável.</p>
                <p><a class="btn btn-outline-danger" href="cardapio.php" role="button">Faça seu pedido</a></p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <img class="first-slide" src="images/massas.jpg" alt="First slide">
            <div class="container">
              <div class="carousel-caption">
                <h1>Quarta Massa</h1>
                <p>Pratos com menor custo va bene! </p>
                <p><a class="btn btn-outline-danger" href="cardapio.php" role="button">Faça seu pedido</a></p>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <img class="first-slide" src="images/carnes.jpg" alt="First slide">
            <div class="container">
              <div class="carousel-caption">
                <h1>Sexta Carnes</h1>
                <p>Os melhores pratos de carnes promocionais.</p>
                <p><a class="btn btn-outline-danger" href="cardapio.php" role="button">Faça seu pedido</a></p>
              </div>
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Voltar</span>
        </a>
        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Avançar</span>
        </a>
      </div>


      <!-- Mensagens de marketing e outras featurezinhas
      ================================================== -->
      <!-- Envolve o resto da página em outro container, para centralizar todo o conteúdo. -->

      <div class="container marketing">
		<h2>Destaques</h2><br>
        <!-- Três colunas de texto, abaixo do carousel -->
		<div class="row">
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
				<img src="images/churrasco-misto.png">
                <div class="card-body">
                  <p class="card-text"><big>Churrasquinho Misto</big></p>
                  <div class="d-flex justify-content-between align-items-center">
                    <big class="text-muted">R$ 21,90</big>
					<div class="btn-group">
					<a class="btn btn-secondary" href="#" role="button">Adicionar ></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
				<img src="images/estrogonofe-de-carne.png">
                <div class="card-body">
                  <p class="card-text"><big>Estrogonofe de Carne</big></p>
                  <div class="d-flex justify-content-between align-items-center">
                    <big class="text-muted">R$ 21,90</big>
					<div class="btn-group">
					<a class="btn btn-secondary" href="#" role="button">Adicionar ></a>
                    </div>
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img src="images/file-a-parmegiana.png">
                <div class="card-body">
                  <p class="card-text"><big>Frango à Parmegiana</big></p>
                  <div class="d-flex justify-content-between align-items-center">
                    
					<big class="text-muted">R$ 15,90</big>
					<div class="btn-group">
					<a class="btn btn-secondary" href="#" role="button">Adicionar ></a>
                    </div>
                    
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img src="images/isca-de-carne.png">
                <div class="card-body">
                  <p class="card-text"><big>Isca de Carne</big></p>
                  <div class="d-flex justify-content-between align-items-center">
                    <big class="text-muted">R$ 14,90</big>
					<div class="btn-group">
					<a class="btn btn-secondary" href="#" role="button">Adicionar ></a>
                    </div>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img src="images/frango-xadrez.png">
                <div class="card-body">
                  <p class="card-text"><big>Frango Xadrez</big></p>
                  <div class="d-flex justify-content-between align-items-center">
					<big class="text-muted">R$ 14,90</big>
					<div class="btn-group">
					<a class="btn btn-secondary" href="#" role="button">Adicionar ></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img src="images/talharim-a-bolonhesa.png">
                <div class="card-body">
                  <p class="card-text"><big>Talharim à Bolonhesa</big></p>
                  <div class="d-flex justify-content-between align-items-center">
                  <big class="text-muted">R$ 16,90</big>
					<div class="btn-group">
					<a class="btn btn-secondary" href="#" role="button">Adicionar ></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img src="images/lasanha-vegana.png">
                <div class="card-body">
                  <p class="card-text"><big>Lasanha Vegana</big></p>
                  <div class="d-flex justify-content-between align-items-center">
                   <big class="text-muted">R$ 18,50</big>
					<div class="btn-group">
					<a class="btn btn-secondary" href="#" role="button">Adicionar ></a>
                    </div>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img src="images/omelete.png">
                <div class="card-body">
                  <p class="card-text"><big>Omelete</big></p>
                  <div class="d-flex justify-content-between align-items-center">
                   <big class="text-muted">R$ 11,90</big>
					<div class="btn-group">
                      <a class="btn btn-secondary" href="#" role="button">Adicionar ></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img src="images/sobrecoxa.png">
                <div class="card-body">
                  <p class="card-text"><big>Sobrecoxa</big></p>
                  <div class="d-flex justify-content-between align-items-center">
                  <big class="text-muted">R$ 11,90</big>
					<div class="btn-group">
					<a class="btn btn-secondary" href="#" role="button">Adicionar ></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>


        <!-- COMEÇAM AS MENCIONADAS FEATUREZINHAS xD -->

        <hr class="featurette-divider">

        <!-- /FIM DAS FEATUREZINHAS *-* -->

      </div><!-- /.container -->

<?php require_once("inc/footer.php"); ?>

