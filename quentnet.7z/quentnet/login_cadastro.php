<?php require_once("inc/header.php"); ?>

      <div class="container marketing">
			<br><br>
			<h2>Login/Cadastro</h2><br>
			<p class="text-justify">Preencha formulários para ter acesso aos pedidos. Caso seja cadastrado, efetue o login.</p>

			<div class="row">
				<div class="col-sm-6">
					<div class="card">
				<div class="card-body">
				<form>
					<div class="form-group">
						<label for="exampleInputEmail1">Login</label>
						<br><input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="E-mail">
						<small id="emailHelp" class="form-text text-muted"></small>
					</div>
			<div class="form-group">
				<label for="exampleInputPassword1"></label>
				<input type="password" class="form-control" id="exampleInputPassword1" placeholder="Senha">
			</div>
				<button type="submit" class="btn btn-danger">Login</button>
					</form>
				</div>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="card">
					<div class="card-body">
				<form>
					<div class="form-group">
						<label for="exampleInputEmail1">Quero me cadastrar</label><br>
						<input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nome">
						<small id="emailHelp" class="form-text text-muted"></small>
					</div>
				<div class="form-group">
						<label for="exampleInputPassword1"></label>
						<input type="password" class="form-control" id="exampleInputPassword1" placeholder="CEP">
				</div>
						<button type="submit" class="btn btn-danger">Cadastrar</button>
				</form>
				</div>
				</div>
				</div>
			</div>

        <!-- COMEÇAM AS MENCIONADAS FEATUREZINHAS xD -->

        <hr class="featurette-divider">

        <!-- /FIM DAS FEATUREZINHAS *-* -->

      
<?php require_once("inc/footer.php"); ?>